package freesloc

import java.io.File

/** lambda template to get stats from a file */
typealias Analyzer = (File) -> SlocStats


//////////
// JAVA
//////////

val javaAnalyzer: Analyzer = { file ->
    // load file lines
    val lineList = file.readLines()

    // set LOC
    val stats = SlocStats()
    stats.lines = lineList.size
    stats.files = 1
    stats.size = file.length()

    // iterate over lines of code
    var block = false
    var docstring = false

    for ( index in 0 until lineList.size )
    {
        val line = lineList[index]

        when
        {
            // docstring
            docstring || line.trimStart().startsWith( "/**" ) && !line.trimStart().startsWith( "/**/" ) -> {
                stats.docstringLines++
                docstring = !line.trimEnd().endsWith( "*/" ) || !docstring && line.trim().length < "/***/".length
            }
            // block comment (no docstring)
            block || line.trimStart().startsWith( "/*" ) -> {
                stats.blockCommentLines++
                block = !line.trimEnd().endsWith( "*/" ) || !block && line.trim().length < "/**/".length
            }
            // single comment
            line.trimStart().startsWith( "//" ) -> stats.singleCommentLines++
            // blank line
            line.isBlank() -> stats.blankLines++
            // lines only with delimiters '{',  '}',  '{}',  '};',  ')};'
            line.trim() in arrayOf( "{", "}", "{}", "};", ")};" ) -> stats.delimiterLines++
        }
    }  // for

    stats
}  // javaAnalyzer

////////////
// KOTLIN
////////////

val kotlinAnalyzer = javaAnalyzer

///////
// C
///////

val cAnalyzer = javaAnalyzer

/////////
// C++
/////////

val cxxAnalyzer = javaAnalyzer

////////////////
// JAVASCRIPT
////////////////

val javascriptAnalyzer = javaAnalyzer

//////////
// HTML
//////////

val htmlAnalyzer: Analyzer = { file ->
    // load file lines
    val lineList = file.readLines()

    // set LOC
    val stats = SlocStats()
    stats.lines = lineList.size
    stats.files = 1
    stats.size = file.length()

    // iterate over lines of code
    var block = false

    for ( index in 0 until lineList.size )
    {
        val line = lineList[index]

        when
        {
            // block comment
            block || line.trimStart().startsWith( "<!--" ) -> {
                stats.blockCommentLines++
                block = !line.trimEnd().endsWith( "-->" ) || !block && line.trim().length < "<!---->".length
            }
            // blank line
            line.isBlank() -> stats.blankLines++
        }
    }  // for

    stats
}  // htmlAnalyzer

/////////
// XML
/////////

val xmlAnalyzer = htmlAnalyzer

/////////
// CSS
/////////

val cssAnalyzer: Analyzer = { file ->
    // load file lines
    val lineList = file.readLines()

    // set LOC
    val stats = SlocStats()
    stats.lines = lineList.size
    stats.files = 1
    stats.size = file.length()

    // iterate over lines of code
    var block = false

    for ( index in 0 until lineList.size )
    {
        val line = lineList[index]

        when
        {
            // block comment
            block || line.trimStart().startsWith( "/*" ) -> {
                stats.blockCommentLines++
                block = !line.trimEnd().endsWith( "*/" ) || !block && line.trim().length < "/**/".length
            }
            // blank line
            line.isBlank() -> stats.blankLines++
        }
    }  // for


    stats
}  // cssAnalyzer

////////////
// PYTHON
////////////

val pythonAnalyzer: Analyzer = { file ->
    // load file lines
    val lineList = file.readLines()

    // set LOC
    val stats = SlocStats()
    stats.lines = lineList.size
    stats.files = 1
    stats.size = file.length()

    // iterate over lines of code
    var docstring1 = false
    var docstring2 = false

    for ( index in 0 until lineList.size )
    {
        val line = lineList[index]

        when
        {
            // docstring comment with """
            docstring1 || line.trimStart().startsWith( """"""""" ) && !docstring2 -> {
                stats.docstringLines++
                docstring1 = !line.trimEnd().endsWith( """"""""" ) || !docstring1 && line.trim().length == """"""""".length
            }
            // docstring comment with '''
            docstring2 || line.trimStart().startsWith( "'''" ) -> {
                stats.docstringLines++
                docstring2 = !line.trimEnd().endsWith( "'''" ) || !docstring2 && line.trim().length == "'''".length
            }
            // single comment
            line.trimStart().startsWith( "#" ) -> stats.singleCommentLines++
            // blank line
            line.isBlank() -> stats.blankLines++
        }
    }  // for

    stats
}  // pythonAnalyzer

/////////
// Go
////////

val goAnalyzer = javaAnalyzer

///////////
// BASIC
///////////

val basicAnalyzer: Analyzer = { file ->
    // load file lines
    val lineList = file.readLines()

    // set LOC
    val stats = SlocStats()
    stats.lines = lineList.size
    stats.files = 1
    stats.size = file.length()

    // iterate over lines of code

    for ( index in 0 until lineList.size )
    {
        val line = lineList[index]

        when
        {
            // single comment
            line.trimStart().startsWith( "'" ) || line.trimStart().toLowerCase().startsWith( "rem " ) ->
                                                                                            stats.singleCommentLines++
            // blank line
            line.isBlank() -> stats.blankLines++
        }
    }  // for

    stats
}

////////////////
// PLAIN TEXT
////////////////

val plainAnalyzer: Analyzer = { file ->
    // load file lines
    val lineList = file.readLines()

    // set LOC
    val stats = SlocStats()
    stats.lines = lineList.size
    stats.files = 1
    stats.size = file.length()

    for ( index in 0 until lineList.size )
    {
        val line = lineList[index]

        // blank line
        if ( line.isBlank() )
            stats.blankLines++
    }

    stats
}  // plainAnalyzer


/** Use language id to get analyzer */
val MAP_LANG_ANALYZER = mapOf( "java" to javaAnalyzer,
                               "kotlin" to kotlinAnalyzer,
                               "c" to cAnalyzer,
                               "c++" to cxxAnalyzer,
                               "python" to pythonAnalyzer,
                               "css" to cssAnalyzer,
                               "js" to javascriptAnalyzer,
                               "html" to htmlAnalyzer,
                               "xml" to xmlAnalyzer,
                               "go" to goAnalyzer,
                               "basic" to basicAnalyzer,
                               "plain" to plainAnalyzer )

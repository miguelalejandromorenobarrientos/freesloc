package freesloc

import java.io.File
import java.util.*
import javax.swing.*
import javax.swing.plaf.metal.MetalLookAndFeel
import javax.swing.plaf.metal.OceanTheme
import kotlin.system.exitProcess

fun main( args: Array<String> )
{
    // console input
    val input = " " + args .joinTo( StringBuilder(),
                                    separator = " ",
                                    transform = { if (it.contains(" ")) "\"$it\"" else it } ).toString() + " "

    // check for language in app
    var regex = """(?:.*\s+)?(?:-lang\s+(\w+)(?:\s+(\w+))?)(?:\s+.*)?""".toRegex( RegexOption.IGNORE_CASE )
    if ( regex.matches(input) )
    {
        // set app language (system default if fails)
        val lang = regex.matchEntire(input)!!.groupValues[1]
        val country = regex.matchEntire(input)!!.groupValues[2]
        appLocale = Locale(lang, country)
    }

    // ask for help
    regex = """(?:.*\s+)?(?:(?:-h)|(?:-help))(?:\s+.*)?""".toRegex(RegexOption.IGNORE_CASE)
    val info = regex.matches(input)
    if (info)
    {
        println(
            """freesloc [-h|-help] [-lang <language> [<country>]] [-path <path>|"<path>"] [-laf <lafname>] [<filetype>]*
                |  Options:
                |   -h|-help                    this message
                |   -lang language country      app language and country in Java format: ie. 'en US', 'es ES', 'fr'
                |   -filetype                   file types for scanning project:
                |                               :java, :c, :c++, :python, :html, :css, :js, :xml, :go, :basic,
                |                               :kotlin, :plain
                |   -path path                  project path (folder or single file)
                |   -laf lafname                Look and Feel (default system):
                |                               system, metal, motif, nimbus, windows, classic, gtk,
                |                               or 'LAF full classname'
                |  e.g.:
                |        java -jar freesloc.jar -path "./project" -lang es :java :kotlin :plain
                |        win executable:  FreeSloc.exe -path "./project" -lang es :java :kotlin :plain
                |""".trimMargin()
        )
        exitProcess(0)
    }

    // check for path
    regex = """(?:.*\s+)?-path\s+((?:"[^"]*")|(?:\S*?))(?:\s+.*)?""".toRegex( RegexOption.IGNORE_CASE )
    var path = if ( regex.matches(input) ) regex.matchEntire(input)!!.groupValues[1] else ""

    // file types in project
    regex = """(?=\s:(\w+)\s)""".toRegex( RegexOption.IGNORE_CASE )
    val matches = regex.findAll(input)
    var typeSet = matches.map { it.groupValues[1] }.toSet()
    // file type error
    if ( !typeSet.all { it in EXTENSION_MAP.keys } )
    {
        println( "${strBundle.getString( "error_unknown_file_type" )}: ${typeSet.filter { it !in EXTENSION_MAP.keys }}")
        exitProcess(-1)
    }
    // set file type to all types if not specified
    if ( typeSet.isEmpty() )
        typeSet = EXTENSION_MAP.keys

    // launch app
    println( "-h for console options." )
    println( "Launching ${strBundle.getString("info_appname")} v${strBundle.getString("info_version")}..." )

    // GUI start
    if ( path.isBlank() || path.equals( "\"\"" ) )
    {
        // check for look and feel
        var laf = UIManager.getSystemLookAndFeelClassName()
        regex = """(?:.*\s+)-laf\s+([\w.]+)(?:\s+.*)?""".toRegex(RegexOption.IGNORE_CASE)
        if ( regex.matches(input) )
        {
            laf = regex.matchEntire(input)!!.groupValues[1]
            laf = when ( laf.toUpperCase() ) {
                "METAL" -> UIManager.getCrossPlatformLookAndFeelClassName()
                "SYSTEM" -> UIManager.getSystemLookAndFeelClassName()
                "MOTIF" -> "com.sun.java.swing.plaf.motif.MotifLookAndFeel"
                "GTK" -> "com.sun.java.swing.plaf.gtk.GTKLookAndFeel"
                "NIMBUS" -> "javax.swing.plaf.nimbus.NimbusLookAndFeel"
                "WINDOWS" -> "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"
                "CLASSIC" -> "com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel"
                else -> laf
            }
        }
        try
        {
            // decoration
            JFrame.setDefaultLookAndFeelDecorated(true)
            JDialog.setDefaultLookAndFeelDecorated(true)

            // themes
            MetalLookAndFeel.setCurrentTheme( OceanTheme() )
            //setCurrentTheme( DefaultMetalTheme() )

            // set LAF
            UIManager.setLookAndFeel( laf )
        }
        catch ( e: Exception ) { println( "ERROR, for LAF $laf: ${e.javaClass.simpleName}" ) }

        // tooltip delay (ms)
        ToolTipManager.sharedInstance().initialDelay = 100 // ms

        // start GUI
        SwingUtilities.invokeLater { FreeSlocGUI().isVisible = true }
    }
    // console output
    else
    {
        path = if ( path.startsWith("\"") ) path.slice( 1 until path.length - 1 ) else path
        if ( File(path).exists() )
            printInConsole( File(path), typeSet )
        else
            println( "${strBundle.getString("error_badpath")} -> $path" )
    }
}  // main

package freesloc

import java.awt.Color
import java.awt.Component
import java.awt.Font
import java.io.File
import javax.swing.BorderFactory
import javax.swing.ImageIcon
import javax.swing.JLabel
import javax.swing.JTree
import javax.swing.tree.DefaultMutableTreeNode
import javax.swing.tree.TreeCellRenderer
import kotlin.math.max

/////////////////////////////
// DefaultRender HIERARCHY
/////////////////////////////

sealed class DefaultRender( txt: Any,
                            font: Font = Font( Font.SERIF, Font.PLAIN, sizesBundle( "fontsize_defaultrender" ) ),
                            icon: ImageIcon? = null,
                            var label: JLabel = JLabel()
                          ): TreeCellRenderer
{
    init
    {
        label.text = txt.toString()
        label.font = font
        label.icon = icon
    }

    override fun getTreeCellRendererComponent( tree: JTree?,
                                               value: Any?,
                                               selected: Boolean,
                                               expanded: Boolean,
                                               leaf: Boolean,
                                               row: Int,
                                               hasFocus: Boolean
                                             ): Component
    {
        return label.apply {
            border = if ( selected ) BorderFactory.createDashedBorder( null, 1f, 3f, 3f, true )
                     else BorderFactory.createEmptyBorder( 1, 1, 1, 1 )
        }
    }
}

class DefaultFileRender( val file: File, var stats: SlocStats? = null )
    : DefaultRender( "" )
{
    override fun getTreeCellRendererComponent( tree: JTree?,
                                               value: Any?,
                                               selected: Boolean,
                                               expanded: Boolean,
                                               leaf: Boolean,
                                               row: Int,
                                               hasFocus: Boolean
                                             ): Component
    {
        super.getTreeCellRendererComponent( tree, value, selected, expanded, leaf, row, hasFocus )

        return label.apply {
            isOpaque = selected
            background = if ( selected ) Color(240,240,240) else tree?.background ?: Color.WHITE
            font = Font( Font.SANS_SERIF, Font.PLAIN, sizesBundle( "tree_file_row_height" ) )
            text = """<html><b>${file.name}</b>${kb(stats)}&emsp<small><i><font color=#999999>
                      |${file.absolutePath}</font></i></small></html>""".trimMargin()
            icon = TREE_SCALED_ICON_MAP[ getLangFileTypeInfo(file.extension)?.id ]
        }
    }
}  // DefaultFileRender

class DefaultFolderRender( val file: File, var stats: SlocStats? = null )
    : DefaultRender( "" )
{
    override fun getTreeCellRendererComponent( tree: JTree?,
                                               value: Any?,
                                               selected: Boolean,
                                               expanded: Boolean,
                                               leaf: Boolean,
                                               row: Int,
                                               hasFocus: Boolean
                                             ): Component
    {
        super.getTreeCellRendererComponent( tree, value, selected, expanded, leaf, row, hasFocus )

        return label.apply {
            isOpaque = selected
            background = if ( selected ) Color(240,240,240) else tree?.background ?: Color.WHITE
            if ( row > 0 )  // packages
            {
                font = Font( Font.SANS_SERIF, Font.ITALIC, sizesBundle( "tree_folder_row_height" ) )
                text = "<html>${file.absolutePath}${kb(stats)}</html>"
                icon = TREE_SCALED_ICON_MAP[ "package" ]
            }
            else  // project root
            {
                font = Font( Font.SANS_SERIF, Font.PLAIN, sizesBundle( "tree_folder_row_height" ) + 2 )
                text = """<html>${strBundle.getString("txt_project")} <b>${file.name}</b>
                          |${kb(stats)}
                          |&emsp;<small><i><font color=#999999>${file.absolutePath}</font></i></small></html>"""
                       .trimMargin()
                icon = TREE_SCALED_ICON_MAP[ "project" ]
            }
        }  // return
    }  // getTreeCellRendererComponent
}  // DefaultFolderRender

class DefaultTotalFilesRender( stats: SlocStats )
    : DefaultRender( """<html>${strBundle.getString("txt_total_files")}: ${stats.files}&emsp;
                        |${if (stats.files>0) "(${(stats.lines.toDouble()/stats.files).format(1)} " +
                         "${strBundle.getString("txt_lines_per_file")})" else ""}</html>""".trimMargin(),
                     icon = TREE_SCALED_ICON_MAP["files"] )

class DefaultTotalLinesRender( stats: SlocStats )
    : DefaultRender( "${strBundle.getString("txt_total_lines")}: ${stats.lines}",
                     icon = TREE_SCALED_ICON_MAP["file_lines"] )

class DefaultSlocRender( stats: SlocStats )
    : DefaultRender( """<html><b>${strBundle.getString("txt_loc")}: ${stats.sloc}</b>&emsp;
                        |(${percentage(stats.sloc,stats.lines)}% ${strBundle.getString("txt_of_the_total")})</html>"""
                     .trimMargin(),
                     Font( Font.SERIF, Font.PLAIN, sizesBundle( "fontsize_defaultrender" ) + 2 ),
                     icon = TREE_SCALED_ICON_MAP["code"] )

class DefaultCommentsRender( stats: SlocStats )
    : DefaultRender( """<html>${strBundle.getString("txt_comment_lines")}: ${stats.commentLines}&emsp;
                        |(${percentage(stats.commentLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")})
                        |</html>""".trimMargin(),
                     icon = TREE_SCALED_ICON_MAP["comments"] )

class DefaultSingleCommentsRender( stats: SlocStats, format: String = "//" )
    : DefaultRender( """<html><b><font color=#AA1177><tt>$format</tt></font></b>&emsp;
                        |${strBundle.getString("txt_single_line")}:
                        |${stats.singleCommentLines}&emsp;(${percentage(stats.singleCommentLines,stats.commentLines)}%
                        |${strBundle.getString("txt_of_the_total_comments")})</html>""".trimMargin() )

class DefaultBlockCommentsRender( stats: SlocStats, format: String = "/* \u2026 */" )
    : DefaultRender( """<html><b><font color=#AA1177><tt>$format</tt></font></b>&emsp;
                        |${strBundle.getString("txt_multiline")}:
                        |${stats.blockCommentLines}&emsp;(${percentage(stats.blockCommentLines,stats.commentLines)}%
                        |${strBundle.getString("txt_of_the_total_comments")})</html>""".trimMargin() )

class DefaultDocstringCommentsRender( stats: SlocStats, format: String = "/** \u2026 */" )
    : DefaultRender( """<html><b><font color=#AA1177><tt>$format</tt></font></b>&emsp;Docstring:
                        |${stats.docstringLines}&emsp;(${percentage(stats.docstringLines,stats.commentLines)}%
                        |${strBundle.getString("txt_of_the_total_comments")})</html>""".trimMargin() )

class DefaultBlanksRender( stats: SlocStats )
    : DefaultRender( """<html>${strBundle.getString("txt_blank_lines")}: ${stats.blankLines}&emsp;
                        |(${percentage(stats.blankLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")})
                        |</html>""".trimMargin(),
                     icon = TREE_SCALED_ICON_MAP["blank"] )

class DefaultNoBlanksRender( stats: SlocStats )
    : DefaultRender( """<html>${strBundle.getString("txt_lines_not_blank")}: ${stats.noBlankLines}&emsp;
                        |(${percentage(stats.noBlankLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")})
                        |</html>""".trimMargin() )

class DefaultDelimitersRender( stats: SlocStats )
    : DefaultRender( """<html>${strBundle.getString("txt_lines_delimiters")}: ${stats.delimiterLines}&emsp;
                        |(${percentage(stats.delimiterLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")},
                        |${percentage(stats.delimiterLines,stats.sloc)}%
                        |${strBundle.getString("txt_total_lines_code")})</html>""".trimMargin(),
                     icon = TREE_SCALED_ICON_MAP["delimiters"] )


////////////////////////
// Console functions
////////////////////////

fun consoleTotalFiles( stats: SlocStats ) = "${strBundle.getString("txt_total_files")}: ${stats.files}  ${if (stats.files>0) "(${(stats.lines.toDouble()/stats.files).format(1)} ${strBundle.getString("txt_lines_per_file")})" else ""}"
fun consoleTotalLines( stats: SlocStats ) = "${strBundle.getString("txt_total_lines")}: ${stats.lines}"
fun consoleSloc( stats: SlocStats ) = "${strBundle.getString("txt_loc")}: ${stats.sloc}  (${percentage(stats.sloc,stats.lines)}% ${strBundle.getString("txt_of_the_total")})"
fun consoleComments( stats: SlocStats ) = "${strBundle.getString("txt_comment_lines")}: ${stats.commentLines}  (${percentage(stats.commentLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")})"
fun consoleSingleComments( stats: SlocStats, format: String = "//" ) = "$format  ${strBundle.getString("txt_single_line")}: ${stats.singleCommentLines}  (${percentage(stats.singleCommentLines,stats.commentLines)}% ${strBundle.getString("txt_of_the_total_comments")})"
fun consoleBlockComments( stats: SlocStats, format: String = "/* ... */" ) = "$format  ${strBundle.getString("txt_multiline")}: ${stats.blockCommentLines}  (${percentage(stats.blockCommentLines,stats.commentLines)}% ${strBundle.getString("txt_of_the_total_comments")})"
fun consoleDocstringComments( stats: SlocStats, format: String = "/** ... */" ) = "$format  Docstring: ${stats.docstringLines}  (${percentage(stats.docstringLines,stats.commentLines)}% ${strBundle.getString("txt_of_the_total_comments")})"
fun consoleBlanks( stats: SlocStats ) = "${strBundle.getString("txt_blank_lines")}: ${stats.blankLines}  (${percentage(stats.blankLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")})"
fun consoleNoBlanks( stats: SlocStats ) = "${strBundle.getString("txt_lines_not_blank")}: ${stats.noBlankLines}  (${percentage(stats.noBlankLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")})"
fun consoleDelimiters( stats: SlocStats ) = "${strBundle.getString("txt_lines_delimiters")}: ${stats.delimiterLines}  (${percentage(stats.delimiterLines,stats.lines)}% ${strBundle.getString("txt_of_the_total")},${percentage(stats.delimiterLines,stats.sloc)}% ${strBundle.getString("txt_total_lines_code")})"

//////////////////////////////////////////////
//////////////// SHOW INFO ///////////////////
//////////////////////////////////////////////

typealias ShowInTree = (DefaultMutableTreeNode,SlocStats) -> Unit
typealias ShowInConsole = (File,SlocStats) -> Unit

/**
 * Create a centered title with left subtitled
 *
 * @param title centered top title
 * @param subtitle left bottom subtitle
 * @param char character for decoration
 * @return final title string
 */
fun title( title: String, subtitle: String = "", char: Char ): String
{
    val length = max( title.length + 2 /*spaces*/, subtitle.length ) + 10 /*space right*/

    return StringBuilder().apply {
        appendln( char.toString().repeat(length) )
        appendln( char.toString().repeat( (length-title.length-2)/2) + " " + title + " "
                  + char.toString().repeat((length-title.length-1)/2) )
        appendln( char.toString().repeat(length) )
        if ( !subtitle.isEmpty() )
        {
            appendln( subtitle )
            appendln( char.toString().repeat(length) )
        }
    }.toString()
}

//////////
// JAVA
//////////

val javaShowInTree: ShowInTree = { parentNode, stats ->
    // total lines
    var nodeValue: DefaultRender = DefaultTotalLinesRender(stats)
    var auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // code lines (without comments)
    nodeValue = DefaultSlocRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // comments
    if ( stats.commentLines > 0 )
    {
        nodeValue = DefaultCommentsRender(stats)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.add(auxNode)

        // single line comments
        if (stats.singleCommentLines > 0) {
            nodeValue = DefaultSingleCommentsRender(stats)
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }

        // block comments
        if (stats.blockCommentLines > 0) {
            nodeValue = DefaultBlockCommentsRender(stats)
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }

        // docstring comments
        if (stats.docstringLines > 0) {
            nodeValue = DefaultDocstringCommentsRender(stats)
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }
    }

    // blank lines
    nodeValue = DefaultBlanksRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    nodeValue = DefaultNoBlanksRender(stats)
    auxNode.add( DefaultMutableTreeNode(nodeValue) )

    // delimiter lines
    nodeValue = DefaultDelimitersRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )
}

val javaShowInConsole: ShowInConsole = { file, stats ->
    print( title( file.name, "  ${file.extension.toUpperCase()} file: ${file.absolutePath}", '·' ) )
    // total lines
    println( "\t${consoleTotalLines(stats)}" )
    // code lines
    println( "\t${consoleSloc(stats)}" )
    // comments
    if ( stats.commentLines > 0 ) {
        println( "\t${consoleComments(stats)}" )
        if ( stats.singleCommentLines > 0 )
            println( "\t\t${consoleSingleComments(stats)}" )
        if ( stats.blockCommentLines > 0 )
            println( "\t\t${consoleBlockComments(stats)}" )
        if ( stats.docstringLines > 0 )
            println( "\t\t${consoleDocstringComments(stats)}" )
    }
    // blank lines
    println( "\t${consoleBlanks(stats)}" )
    println( "\t\t${consoleNoBlanks(stats)}" )
    // delimiters
    println( "\t${consoleDelimiters(stats)}" )
}

////////////
// KOTLIN
////////////

val kotlinShowInTree = javaShowInTree
val kotlinShowInConsole = javaShowInConsole

///////
// C
///////

val cShowInTree = javaShowInTree
val cShowInConsole = javaShowInConsole

/////////
// C++
/////////

val cxxShowInTree = javaShowInTree
val cxxShowInConsole = javaShowInConsole

////////////////
// JAVASCRIPT
////////////////

val javascriptShowInTree = javaShowInTree
val javascriptShowInConsole = javaShowInConsole

/////////
// CSS
/////////

val cssShowInTree: ShowInTree = { parentNode, stats ->
    // total lines
    var nodeValue: DefaultRender = DefaultTotalLinesRender(stats)
    var auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // code lines (without comments)
    nodeValue = DefaultSlocRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // comments
    if ( stats.commentLines > 0 )
    {
        nodeValue = DefaultCommentsRender(stats)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.add(auxNode)

        // block comments
        if (stats.blockCommentLines > 0) {
            nodeValue = DefaultBlockCommentsRender(stats)
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }
    }

    // blank lines
    nodeValue = DefaultBlanksRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    nodeValue = DefaultNoBlanksRender(stats)
    auxNode.add( DefaultMutableTreeNode(nodeValue) )
}

val cssShowInConsole: ShowInConsole = { file, stats ->
    print( title( file.name, "  ${file.extension.toUpperCase()} file: ${file.absolutePath}", '·' ) )
    // total lines
    println( "\t${consoleTotalLines(stats)}" )
    // code lines
    println( "\t${consoleSloc(stats)}" )
    // comments
    if ( stats.commentLines > 0 ) {
        println( "\t${consoleComments(stats)}" )
        if ( stats.blockCommentLines > 0 )
            println( "\t\t${consoleBlockComments(stats,"<!-- ... -->")}" )
    }
    // blank lines
    println( "\t${consoleBlanks(stats)}" )
    println( "\t\t${consoleNoBlanks(stats)}" )
}

/////////////
// PYTHON
/////////////

val pythonShowInTree: ShowInTree = { parentNode, stats ->
    // total lines
    var nodeValue: DefaultRender = DefaultTotalLinesRender(stats)
    var auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // code lines (without comments)
    nodeValue = DefaultSlocRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // comments
    if ( stats.commentLines > 0 )
    {
        nodeValue = DefaultCommentsRender(stats)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.add(auxNode)

        // single line comments
        if (stats.singleCommentLines > 0) {
            nodeValue = DefaultSingleCommentsRender( stats, "#" )
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }

        // docstring comments
        if (stats.docstringLines > 0) {
            nodeValue = DefaultDocstringCommentsRender( stats, "''' \u2026 '''" )
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }
    }

    // blank lines
    nodeValue = DefaultBlanksRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    nodeValue = DefaultNoBlanksRender(stats)
    auxNode.add( DefaultMutableTreeNode(nodeValue) )
}

val pythonShowInConsole: ShowInConsole = { file, stats ->
    print( title( file.name, "  ${file.extension.toUpperCase()} file: ${file.absolutePath}", '·' ) )
    // total lines
    println( "\t${consoleTotalLines(stats)}" )
    // code lines
    println( "\t${consoleSloc(stats)}" )
    // comments
    if ( stats.commentLines > 0 ) {
        println( "\t${consoleComments(stats)}" )
        if ( stats.singleCommentLines > 0 )
            println( "\t\t${consoleSingleComments(stats,"#")}" )
        if ( stats.docstringLines > 0 )
            println( "\t\t${consoleDocstringComments(stats,"''' ... '''")}" )
    }
    // blank lines
    println( "\t${consoleBlanks(stats)}" )
    println( "\t\t${consoleNoBlanks(stats)}" )
}

//////////
// HTML
//////////

val htmlShowInTree: ShowInTree = { parentNode, stats ->
    // total lines
    var nodeValue: DefaultRender = DefaultTotalLinesRender(stats)
    var auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // code lines (without comments)
    nodeValue = DefaultSlocRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // comments
    if ( stats.commentLines > 0 )
    {
        nodeValue = DefaultCommentsRender(stats)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.add(auxNode)

        // block comments
        if (stats.blockCommentLines > 0) {
            nodeValue = DefaultBlockCommentsRender( stats, "&lt;!-- \u2026 -->" )
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }
    }

    // blank lines
    nodeValue = DefaultBlanksRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    nodeValue = DefaultNoBlanksRender(stats)
    auxNode.add( DefaultMutableTreeNode(nodeValue) )
}

val htmlShowInConsole: ShowInConsole = { file, stats ->
    print( title( file.name, "  ${file.extension.toUpperCase()} file: ${file.absolutePath}", '·' ) )
    // total lines
    println( "\t${consoleTotalLines(stats)}" )
    // code lines
    println( "\t${consoleSloc(stats)}" )
    // comments
    if ( stats.commentLines > 0 ) {
        println( "\t${consoleComments(stats)}" )
        if ( stats.blockCommentLines > 0 )
            println( "\t\t${consoleBlockComments(stats,"<!-- ... -->")}" )
    }
    // blank lines
    println( "\t${consoleBlanks(stats)}" )
    println( "\t\t${consoleNoBlanks(stats)}" )
    // delimiters
    println( "\t${consoleDelimiters(stats)}" )
}

/////////
// PHP
/////////

val phpShowInTree = htmlShowInTree
val phpShowInConsole = htmlShowInConsole

/////////
// XML
/////////

val xmlShowInTree = htmlShowInTree
val xmlShowInConsole = htmlShowInConsole

////////
// GO
////////

val goShowInTree = javaShowInTree
val goShowInConsole = javaShowInConsole

///////////
// BASIC
///////////

val basicShowInTree: ShowInTree = { parentNode, stats ->
    // total lines
    var nodeValue: DefaultRender = DefaultTotalLinesRender(stats)
    var auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // code lines (without comments)
    nodeValue = DefaultSlocRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // comments
    if ( stats.commentLines > 0 )
    {
        nodeValue = DefaultCommentsRender(stats)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.add(auxNode)

        // single comments
        if ( stats.singleCommentLines > 0 ) {
            nodeValue = DefaultSingleCommentsRender( stats, "' <small>(REM)</small>" )
            auxNode.add(DefaultMutableTreeNode(nodeValue))
        }
    }

    // blank lines
    nodeValue = DefaultBlanksRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    nodeValue = DefaultNoBlanksRender(stats)
    auxNode.add( DefaultMutableTreeNode(nodeValue) )
}

val basicShowInConsole: ShowInConsole = { file, stats ->
    print( title( file.name, "  ${file.extension.toUpperCase()} file: ${file.absolutePath}", '·' ) )
    // total lines
    println( "\t${consoleTotalLines(stats)}" )
    // code lines
    println( "\t${consoleSloc(stats)}" )
    // comments
    if ( stats.commentLines > 0 ) {
        println( "\t${consoleComments(stats)}" )
        if ( stats.singleCommentLines > 0 )
            println( "\t\t${consoleSingleComments(stats,"' (REM)")}" )
    }
    // blank lines
    println( "\t${consoleBlanks(stats)}" )
    println( "\t\t${consoleNoBlanks(stats)}" )
}

////////////////
// PLAIN TEXT
////////////////

val plainShowInTree: ShowInTree = { parentNode, stats ->
    // total lines
    var nodeValue: DefaultRender = DefaultTotalLinesRender(stats)
    var auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    // blank lines
    nodeValue = DefaultBlanksRender(stats)
    auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.add( auxNode )

    nodeValue = DefaultNoBlanksRender(stats)
    auxNode.add( DefaultMutableTreeNode(nodeValue) )
}

val plainShowInConsole: ShowInConsole = { file, stats ->
    print( title( file.name, "  ${file.extension.toUpperCase()} file: ${file.absolutePath}", '·' ) )
    // total lines
    println( "\t${consoleTotalLines(stats)}" )
    // blank lines
    println( "\t${consoleBlanks(stats)}" )
    println( "\t\t${consoleNoBlanks(stats)}" )
}

/////////////
// FOLDERS
/////////////


val folderShowInTree : ShowInTree = { parentNode, stats ->

    fun changeColorForRoot( label: JLabel )
    {
        if ( parentNode.isRoot )
        {
            label.isOpaque = true
            label.background = Color( 222, 255, 222 )
            label.foreground = Color.BLUE
        }
    }

    // total files
    var nodeValue: DefaultRender = DefaultTotalFilesRender(stats)
    changeColorForRoot( nodeValue.label )
    var auxNode = DefaultMutableTreeNode( nodeValue )
    parentNode.insert( auxNode, 0 )

    if ( stats.files > 0 )
    {
        // total lines
        nodeValue = DefaultTotalLinesRender(stats)
        changeColorForRoot(nodeValue.label)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.insert(auxNode, 1)

        // code lines (without comments)
        nodeValue = DefaultSlocRender(stats)
        changeColorForRoot(nodeValue.label)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.insert(auxNode, 2)

        val comments = stats.commentLines > 0

        // comments
        if (comments) {
            nodeValue = DefaultCommentsRender(stats)
            changeColorForRoot(nodeValue.label)
            auxNode = DefaultMutableTreeNode(nodeValue)
            parentNode.insert(auxNode, 3)

            // single line comments
            if (stats.singleCommentLines > 0) {
                nodeValue = DefaultSingleCommentsRender(stats, "")
                changeColorForRoot(nodeValue.label)
                auxNode.add(DefaultMutableTreeNode(nodeValue))
            }

            // block comments
            if (stats.blockCommentLines > 0) {
                nodeValue = DefaultBlockCommentsRender(stats, "")
                changeColorForRoot(nodeValue.label)
                auxNode.add(DefaultMutableTreeNode(nodeValue))
            }

            // docstring comments
            if (stats.docstringLines > 0) {
                nodeValue = DefaultDocstringCommentsRender(stats, "")
                changeColorForRoot(nodeValue.label)
                auxNode.add(DefaultMutableTreeNode(nodeValue))
            }
        }

        // blank lines
        nodeValue = DefaultBlanksRender(stats)
        changeColorForRoot(nodeValue.label)
        auxNode = DefaultMutableTreeNode(nodeValue)
        parentNode.insert(auxNode, if (comments) 4 else 3)

        nodeValue = DefaultNoBlanksRender(stats)
        changeColorForRoot(nodeValue.label)
        auxNode.add(DefaultMutableTreeNode(nodeValue))

        // delimiter lines
        if (stats.delimiterLines > 0) {
            nodeValue = DefaultDelimitersRender(stats)
            changeColorForRoot(nodeValue.label)
            auxNode = DefaultMutableTreeNode(nodeValue)
            parentNode.insert(auxNode, if (comments) 5 else 4)
        }
    }
}

val folderShowInConsole: ShowInConsole = { file, stats ->
    print( title( "${strBundle.getString("txt_folder")}:  ${file.absolutePath}", "", '=' ) )
    // total files
    println( "\t${consoleTotalFiles(stats)}" )
    // total lines
    println( "\t${consoleTotalLines(stats)}" )
    println( "\t${consoleSloc(stats)}" )
    if ( stats.commentLines > 0 )
    {
        println( "\t${consoleComments(stats)}" )
        if ( stats.singleCommentLines > 0 )
            println( "\t\t${consoleSingleComments(stats,"")}" )
        if ( stats.blockCommentLines > 0 )
            println( "\t\t${consoleBlockComments(stats,"")}" )
        if ( stats.docstringLines > 0 )
            println( "\t\t${consoleDocstringComments(stats,"")}" )
    }
    println( "\t${consoleBlanks(stats)}" )
    println( "\t\t${consoleNoBlanks(stats)}" )
    println( "\t${consoleDelimiters(stats)}" )
}


////////////////////////////////////////////////
// Maps to get suitable function for language
////////////////////////////////////////////////

/** Map with functions to create node stats for every language */
val MAP_SHOW_IN_TREE = mapOf( "java" to javaShowInTree,
                              "kotlin" to kotlinShowInTree,
                              "c" to cShowInTree,
                              "c++" to cxxShowInTree,
                              "python" to pythonShowInTree,
                              "js" to javascriptShowInTree,
                              "css" to cssShowInTree,
                              "html" to htmlShowInTree,
                              "xml" to xmlShowInTree,
                              "php" to phpShowInTree,
                              "go" to goShowInTree,
                              "basic" to basicShowInTree,
                              "plain" to plainShowInTree,
                              "_folder" to folderShowInTree )

/** Map with functions to print stats in console for every language */
val MAP_IN_CONSOLE = mapOf( "java" to javaShowInConsole,
                            "kotlin" to kotlinShowInConsole,
                            "c" to cShowInConsole,
                            "c++" to cxxShowInConsole,
                            "python" to pythonShowInConsole,
                            "js" to javascriptShowInConsole,
                            "css" to cssShowInConsole,
                            "html" to htmlShowInConsole,
                            "xml" to xmlShowInConsole,
                            "php" to phpShowInConsole,
                            "go" to goShowInConsole,
                            "basic" to basicShowInConsole,
                            "plain" to plainShowInConsole,
                            "_folder" to folderShowInConsole )


fun kb( stats: SlocStats? ) = if ( stats != null )
                                  "&emsp;<small><font color=#AAAAFF>(${(stats.size/1000.0) format 2}KB)</font></small>"
                              else ""


/** Print stats info in console mode */
fun printInConsole( rootFile: File, typeSet: Set<String> ): SlocStats
{
    return if ( rootFile.isDirectory )  // folder
    {
        var statsAcc = SlocStats()

        for ( file in rootFile.listFiles() )
            statsAcc += printInConsole( file, typeSet )

        MAP_IN_CONSOLE["_folder"]!!( rootFile, statsAcc )
        println()

        statsAcc
    }
    else  // file
    {
        val lang = getLangFileTypeInfo( rootFile.extension )
        if ( lang?.id in typeSet ) {
            val stats = MAP_LANG_ANALYZER[lang?.id]!!(rootFile)
            MAP_IN_CONSOLE[lang?.id]!!( rootFile, stats )
            println()
            stats
        } else
            SlocStats()
    }
}

package freesloc

import java.awt.*
import java.awt.event.MouseAdapter
import java.awt.event.MouseEvent
import java.io.File
import javax.swing.*
import javax.swing.event.HyperlinkEvent
import javax.swing.tree.*
import javax.swing.tree.TreeSelectionModel.SINGLE_TREE_SELECTION

/**
 * Application GUI
 */
class FreeSlocGUI : JFrame()
{
    /** Tree for file/stats info */
    private var currentTree: JTree = JTree( null as TreeNode? )

    /** Worker thread for calculating stats */
    private var countWorker: SwingWorker<Unit,Int>? = null

    private val toolbar = JToolBar( "${strBundle.getString( "info_appname" )} toolbar" )
    private val btnOpen = JButton(
            loadIcon("images/open.png")?.scaledIcon( sizesBundle("btn_icon_size"), sizesBundle("btn_icon_size") ) )
    private val btnCount = JButton(
            loadIcon("images/abacus.png")?.scaledIcon( sizesBundle("btn_icon_size"), sizesBundle("btn_icon_size") ) )
    private val btnExpand = JButton(
        loadIcon("images/expand_all.png")?.scaledIcon( sizesBundle("btn_icon_size"), sizesBundle("btn_icon_size") ) )
    private val btnCollapse = JButton(
        loadIcon("images/collapse_all.png")?.scaledIcon( sizesBundle("btn_icon_size"), sizesBundle("btn_icon_size") ) )
    private val btnAbout = JButton(
        loadIcon("images/info.png")?.scaledIcon( sizesBundle("btn_icon_size"), sizesBundle("btn_icon_size") ) )
    private val panelProgress = JPanel()
    private val progressbar = JProgressBar()
    private val btnStop = JButton(
        loadIcon("images/stop.png")?.scaledIcon( 24, 24/*,sizesBundle("btn_icon_size"), sizesBundle("btn_icon_size")*/ ) )
    private val scroll = JScrollPane()
    private val txtPath = JTextField()

    private val fileChooser = JFileChooser()

    private val checksFileType = mutableListOf<JCheckBox>()

    private val selectedLanguages
        get() = checksFileType.filter { it.isSelected }.map { it.getClientProperty( "lang" ) as LangFileTypeInfo }


    init
    {
        fileChooser.fileSelectionMode = JFileChooser.FILES_AND_DIRECTORIES

        // panelMain
        val panelMain = JPanel( BorderLayout() )
        contentPane.add( panelMain, BorderLayout.CENTER )

        // panel CENTER
        val panelCenter = JPanel( BorderLayout() )
        panelMain.add( panelCenter, BorderLayout.CENTER )

        // toolbar
        panelCenter.add( toolbar, BorderLayout.NORTH )

        // scroll and tree
        panelCenter.add( scroll )
        scroll.background = Color( 222, 240, 255 )
        scroll.setViewportView( currentTree )

        // panel WEST
        val panelWest = JPanel()
        panelWest.layout = BoxLayout( panelWest, BoxLayout.Y_AXIS )
        panelMain.add( JScrollPane( panelWest ), BorderLayout.WEST )

        // checksFileType
        EXTENSION_MAP.forEach {
            JCheckBox( it.value.name ).apply {
                font = Font( Font.SANS_SERIF, Font.BOLD, sizesBundle( "checks_size" ) )
                putClientProperty( "lang", it.value )
                toolTipText = it.value.extensions.joinToString( ",", "(", ")" ) { ext -> ".$ext" }
                selectedIcon = it.value.icon?.scaledIcon( 2*font.size, 2*font.size) ?: icon
                addActionListener { reloadFileTree( File(txtPath.text), false ) }
                if ( it.value.icon != null )
                    icon = ImageIcon(
                        GrayFilter.createDisabledImage( it.value.icon?.scaledIcon( 2*font.size, 2*font.size )?.image ) )
                checksFileType.add( this )
            }
        }
        checksFileType.forEach { panelWest.add( Box.createVerticalStrut(8) ); panelWest.add( it ) }

        // btnOpen
        toolbar.add( btnOpen )
        btnOpen.toolTipText = strBundle.getString( "btn_open" )
        btnOpen.addActionListener {
            if ( fileChooser.showOpenDialog( this ) == JFileChooser.APPROVE_OPTION )
            {
                // cancel count worker if running
                countWorker?.cancel(true)
                // set path in editor
                txtPath.text = fileChooser.selectedFile.absolutePath
                // reload tree
                reloadFileTree( File( txtPath.text ) )
            }
        }

        // btnCount
        toolbar.add( btnCount )
        btnCount.toolTipText = strBundle.getString( "btn_count" )
        btnCount.addActionListener { countAction() }

        toolbar.addSeparator()

        // btnExpand
        toolbar.add( btnExpand )
        btnExpand.toolTipText = strBundle.getString( "btn_expand_all" )
        btnExpand.addActionListener { currentTree.expandAll() }

        // btnCollapse
        toolbar.add( btnCollapse )
        btnCollapse.toolTipText = strBundle.getString( "btn_collapse_all" )
        btnCollapse.addActionListener { currentTree.collapseAll() }

        toolbar.addSeparator()

        // btnAbout
        toolbar.add( btnAbout )
        btnAbout.toolTipText = strBundle.getString( "btn_about" )
        btnAbout.addActionListener { infoDialog() }

        // panelProgress
        progressbar.isStringPainted = true
        panelProgress.add( progressbar )
        panelProgress.add( btnStop )
        //btnStop.isBorderPainted = true
        //btnStop.isContentAreaFilled = true
        btnStop.border = BorderFactory.createEmptyBorder( 2, 2, 2, 2 )
        btnStop.addActionListener { countWorker?.cancel( true ) }
        toolbar.add( panelProgress )
        panelProgress.isVisible = false

        // txtPath
        panelMain.add( txtPath, BorderLayout.NORTH )
        txtPath.font = Font( Font.SANS_SERIF, Font.BOLD, sizesBundle( "path_size" ) )
        txtPath.toolTipText = strBundle.getString( "tooltip_path" )
        txtPath.background = Color( 244, 244, 255 )
        txtPath.addActionListener { reloadFileTree( File( txtPath.text ) ) }

        // window config
        title = "${strBundle.getString("info_appname")}  v${strBundle.getString("info_version")}  -  (C) ${strBundle.getString("info_copyleft")}"
        iconImage = ImageIcon( javaClass.getResource( "/images/free_sloc_logo.png" ) ).image
        defaultCloseOperation = EXIT_ON_CLOSE
        preferredSize = Dimension( 800, 600 )
        pack()
        extendedState = extendedState or MAXIMIZED_BOTH
        setLocationRelativeTo( null )
    }  // init

    inner class CountWorker: SwingWorker<Unit,Int>()
    {
        init
        {
            panelProgress.isVisible = true
        }

        override fun doInBackground()
        {
            publish(0)

            val numNodes = currentTree.numberNodes()
            var count = 0

            // add file stats to tree
            currentTree.visitAllPreorder(currentTree.model.root as TreeNode) { node ->
                if (!isCancelled && node is DefaultMutableTreeNode && node.userObject is DefaultFileRender)
                {
                    val file = (node.userObject as DefaultFileRender).file
                    val lang = getLangFileTypeInfo(file.extension)?.id ?: ""
                    val analyzer: Analyzer? = MAP_LANG_ANALYZER[lang]
                    if (analyzer != null)
                    {
                        val stats = analyzer(file)
                        (node.userObject as DefaultFileRender).stats = stats
                        MAP_SHOW_IN_TREE.getValue(lang)(node, stats)
                    }

                    // progress
                    count++
                    publish( percentage( count, numNodes ).toInt() )
                }
            }  // visitAllPreorder

            // add folders/packages stats to tree
            currentTree.visitAllPostorder(currentTree.model.root as TreeNode) { node ->
                if ( node.isLeaf )
                    count++
                if (!isCancelled && !node.isLeaf && (node as DefaultMutableTreeNode).userObject is DefaultFolderRender)
                {
                    var statsAcc = SlocStats()  // stats accumulator from every file/folder

                    for (index in 0 until node.childCount)
                    {
                        val child = node.getChildAt(index) as DefaultMutableTreeNode
                        val childValue = child.userObject
                        val stats = when (childValue)
                        {
                            is DefaultFileRender -> childValue.stats
                            is DefaultFolderRender -> childValue.stats
                            else -> null
                        }
                        if (stats != null)
                            statsAcc += stats
                    }

                    // set folder node stats
                    (node.userObject as DefaultFolderRender).stats = statsAcc
                    // add stat nodes to folder
                    MAP_SHOW_IN_TREE["_folder"]!!(node, statsAcc)

                    // progress
                    count++
                    publish( percentage( count, numNodes ).toInt() )
                }
            }  // visitAllPostorder

            if ( !isCancelled)
                publish(100)
        }

        override fun process(chunks: MutableList<Int>?)
        {
            progressbar.value = chunks!![chunks.size-1]
        }

        override fun done()
        {
            countWorker = null
            panelProgress.isVisible = false

            // update and expand tree
            if ( !isCancelled )
            {
                (currentTree.model as DefaultTreeModel).reload()
                currentTree.expandAll()
            }
        }
    }

    private fun countAction()
    {
        // create new file tree
        currentTree = createFileTree( File( txtPath.text ) )
        // failed path, cancel
        if ( !File( txtPath.text ).exists() )
        {
            currentTree = JTree( null as TreeNode? )
            return
        }

        scroll.setViewportView( currentTree )

        println( "Counting for project ${txtPath.text}" )

        // cancel previous count worker if running
        countWorker?.cancel(true)
        // execute new count worker
        countWorker = CountWorker()
        countWorker!!.execute()
    }

    private fun createFileTree( rootFile: File ): JTree
    {
        // create tree
        val tree = object: JTree() {
            init
            {
                selectionModel.selectionMode = SINGLE_TREE_SELECTION
                addMouseListener( object: MouseAdapter() {
                    override fun mouseClicked( e: MouseEvent )
                    {
                        // open folder or open source code file in message dialog
                        if ( e.clickCount == 2 && e.button == MouseEvent.BUTTON3 )
                        {
                            val path: TreePath = getPathForLocation( e.x, e.y ) ?: return
                            val node = path.getPathComponent( path.pathCount - 1 ) as DefaultMutableTreeNode
                            when ( node.userObject )
                            {
                                // open file
                                is DefaultFileRender -> {
                                    val file = (node.userObject as DefaultFileRender).file
                                    if ( file.exists() )
                                        JTextArea( 25, 100 ).apply {
                                            isEditable = false
                                            tabSize = 2
                                            file.readLines().forEach { append( it + System.lineSeparator() ) }
                                            caretPosition = 0
                                            JOptionPane.showMessageDialog( this@FreeSlocGUI,
                                                                           JScrollPane(this),
                                                                           file.name,
                                                                           JOptionPane.INFORMATION_MESSAGE )
                                        }
                                }
                                // open folder
                                is DefaultFolderRender -> {
                                    val file = (node.userObject as DefaultFolderRender).file
                                    if ( file.exists() && Desktop.isDesktopSupported() )
                                        Desktop.getDesktop().open( file )
                                }
                            }
                        }
                    }
                })

                setCellRenderer { tree, value, selected, expanded, leaf, row, hasFocus ->

                    val nodeValue = (value as DefaultMutableTreeNode).userObject

                    if ( nodeValue is TreeCellRenderer )
                        return@setCellRenderer nodeValue.getTreeCellRendererComponent(
                                                                tree, value, selected, expanded, leaf, row, hasFocus )

                    DefaultTreeCellRenderer().getTreeCellRendererComponent(
                                                                tree, value, selected, expanded, leaf, row, hasFocus )
                }
            }
        }  // object: JTree
        tree.rowHeight = sizesBundle( "tree_row_height" )

        // recursive function for adding filtered files and folders/packages
        fun addFileNode( parentNode: DefaultMutableTreeNode?, file: File ): DefaultMutableTreeNode?
        {
            // add new node to parent with the file
            if ( !file.isDirectory && getSelectedLangFileTypeInfo( file.extension ) == null )
                return null
            val newNode = DefaultMutableTreeNode(
                                        if( file.isDirectory ) DefaultFolderRender(file) else DefaultFileRender(file) )
            parentNode?.add( newNode )
            // iterate over folders/packages
            if ( file.isDirectory )
            {
                for ( innerFile in file.listFiles() )
                    addFileNode( newNode, innerFile )
            }

            return newNode
        }

        // load nodes from root
        tree.model = DefaultTreeModel( addFileNode( null, rootFile ) )

        // expanded initially
        tree.expandAll()

        return tree
    }

    /**
     * Reload and repaint tree from a specified file
     */
    private fun reloadFileTree( file: File, showError: Boolean = true )
    {
        if ( file.exists() )
        {
            (currentTree.model.root as? DefaultMutableTreeNode)?.removeAllChildren()
            // create and set tree in GUI
            currentTree = createFileTree(file)
            scroll.setViewportView(currentTree)
            // refresh and expand tree
            (currentTree.model as DefaultTreeModel).reload()
            currentTree.expandAll()
        }
        else if ( showError )
            JOptionPane.showMessageDialog( this,
                                           "<html>${strBundle.getString("error_for_path")} <b>$file</b></html>",
                                           strBundle.getString( "error_badpath" ),
                                           JOptionPane.ERROR_MESSAGE )
    }

    private fun infoDialog()
    {
        // panel HTML
        val editor = JEditorPane().apply {
            contentType = "text/html"
            isEditable = false
            isOpaque = false
            margin = Insets( 0, 10, 0, 50 )
            text = """<html>
                    <b><font size=7 color=green>${strBundle.getString("info_appname")}</font>&emsp;<font size=4 color=green>v${strBundle.getString("info_version")}</font></b><br>
                    <small><br>&emsp;Author: ${strBundle.getString("info_author")},<br>&emsp;&emsp;&emsp;&emsp;&emsp;IT by Córdoba University, Spain</small><br>
                    <br><br>
                    <b>${strBundle.getString("info_appname")}</a></b>
                     is a lightweight application for counting <u>physical lines of code</u>&emsp;<small>(<b>NOT</b> logical lines of code '<i>LLOC</i>')</small>
                    <br/>for many format files, as Java, Python, C, C++, HTML,..., as well as <i>comment</i> lines, <i>blank</i> lines
                    <br>and <i>delimiter</i> lines.
                    <br><br>For using ${strBundle.getString("info_appname")} in <u>console mode</u>, type <b>-h</b> in shell to print options.
                    <br>For viewing file/folder selected in tree, double-click with secondary button.
                    <br><br>
                    <a href="https://sourceforge.net/projects/free-sloc/">Project support at <b>Sourceforge</b></a>
                    <br><br>
                    This software is distributed under GPLv3 license
                    <br><a href='http://www.gnu.org/licenses/gpl-3.0.html'>http://www.gnu.org/licenses/gpl-3.0.html</a>
                    <br><br>
                    (C) ${strBundle.getString("info_copyleft")}
                    </html>"""
            // enable hyperlinks
            addHyperlinkListener { e ->
                if ( e.eventType == HyperlinkEvent.EventType.ACTIVATED && Desktop.isDesktopSupported() )
                    Desktop.getDesktop().browse( e.url.toURI() )
            }
        }

        // show about dialog
        JOptionPane.showMessageDialog( this,
                                       editor,
                                       "About ${strBundle.getString("info_appname")}",
                                       JOptionPane.INFORMATION_MESSAGE,
                                       loadIcon( "images/free_sloc_logo.png" )?.scaledIcon( 75, 128 ) )
    }

    /** Get LangFileTypeInfo for specified selected file extension */
    private fun getSelectedLangFileTypeInfo( extension: String ) =
                                                    selectedLanguages.find { extension.toLowerCase() in it.extensions }
}  // class FreeSlocGUI

package freesloc

import java.util.*

/** current app locale */
var appLocale: Locale = Locale.getDefault()

/** String bundle for app texts */
val strBundle: ResourceBundle
    get() = ResourceBundle.getBundle( "Txt", appLocale )

/** Integer bundle for font,icon,... sizes */
val sizesBundle = { id: String -> ResourceBundle.getBundle( "Sizes" ).getString(id).toInt() }

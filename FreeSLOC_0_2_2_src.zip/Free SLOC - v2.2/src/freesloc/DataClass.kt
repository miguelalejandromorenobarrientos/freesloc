package freesloc

import javax.swing.ImageIcon

/** Data class to store programming language basic info */
data class LangFileTypeInfo( val id: String,
                             val name: String,
                             val extensions: Array<String>,
                             val icon: ImageIcon? = null )


/** Data class to store basic stats parameters about a code file */
data class SlocStats( var lines: Int = 0,  // all lines in file
                      var blankLines: Int = 0,  // black lines
                      var singleCommentLines: Int = 0,  // one line comments
                      var blockCommentLines: Int = 0,  // block comments (could have one line)
                      var docstringLines: Int = 0,  // documentation block comments (could have one line)
                      var delimiterLines: Int = 0,  // lines starting or finishing with specified delimiters
                      var size: Long = 0L,  // size in bytes
                      var files: Int = 0,  // # of files
                      var extra: Any? = null )  // extra data
{
    /** All comment lines */
    val commentLines
        get() = singleCommentLines + blockCommentLines + docstringLines

    /** Lines of code (without comments or blank lines) */
    val sloc
        get() = lines - commentLines - blankLines

    /** Lines of code with comments */
    val noBlankLines
        get() = lines - blankLines

    operator fun plus( other: SlocStats ) = SlocStats( lines + other.lines,
                                                       blankLines + other.blankLines,
                                                       singleCommentLines + other.singleCommentLines,
                                                       blockCommentLines + other.blockCommentLines,
                                                       docstringLines + other.docstringLines,
                                                       delimiterLines + other.delimiterLines,
                                                       size + other.size,
                                                       files + other.files )
}

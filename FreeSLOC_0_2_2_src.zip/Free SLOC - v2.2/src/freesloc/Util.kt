package freesloc

import javax.swing.ImageIcon

/**
 * Load icon from URL
 *
 * @return ImageIcon (null if fails)
 */
fun loadIcon( url: String ) = try { ImageIcon( ClassLoader.getSystemClassLoader().getResource(url) ) }
                              catch ( e: NullPointerException ) { null }

/**
 *  Rounded percentage for a ratio [a]/[b]
 */
fun percentage( a: Int, b: Int ) = Math.round( 100 * a.toDouble() / b )

/**
 * Get language info from a file extension
 *
 * @param extension file extension without dot
 * @return LangFileTypeInfo for that extension
 */
fun getLangFileTypeInfo( extension: String ) = EXTENSION_MAP.values.find { extension.toLowerCase() in it.extensions }

/** Store all language basic info */
val EXTENSION_MAP = mapOf(
        "java" to LangFileTypeInfo(
            "java", "Java", arrayOf("java", ".jav"), loadIcon( "images/lang/java.png" )
        ),
        "c" to LangFileTypeInfo(
            "c", "C", arrayOf("c", "h", "lex"), loadIcon("images/lang/c.png")
        ),
        "c++" to LangFileTypeInfo(
            "c++", "C++",
            arrayOf("c", "h", "cc", "cpp", "c++", "cxx", "cp", "hpp", "h++", "hxx", "hh", "hc", "ino", "i", "inl"),
            loadIcon("images/lang/c++.png")
        ),
        "kotlin" to LangFileTypeInfo(
            "kotlin", "Kotlin", arrayOf("kt", "kts"), loadIcon("images/lang/kotlin.png")
        ),
        "python" to LangFileTypeInfo(
            "python", "Python",
            arrayOf("py", "pyc", "pyd", "pyo", "pyw", "pyz", "rpy", "cpy", "gyp", "gypi", "pyi", "ipy"),
            loadIcon("images/lang/python.png")
        ),
        "html" to LangFileTypeInfo(
            "html", "HTML", arrayOf("html", "htm", "shtml", "shtm", "xhtml", "xht", "hta", "mdoc", "jshtm", "volt"),
            loadIcon("images/lang/html5.png")
        ),
        "css" to LangFileTypeInfo(
            "css", "CSS", arrayOf("css"), loadIcon("images/lang/css.png")
        ),
        "js" to LangFileTypeInfo(
            "js", "Javascript", arrayOf( "js", "mjs", "jsm", "jsx", "ts", "tsx", "es6", "pac" ),
            loadIcon("images/lang/javascript.png")
        ),
        "xml" to LangFileTypeInfo(
            "xml", "XML", arrayOf("xml", "xaml", "xsl", "xslt", "xsd", "xul", "kml", "svg", "mxml", "xsml", "wsdl",
                                  "xlf", "xliff", "xbl", "sxbl", "sitemap", "gml", "gpx", "plist", "ascx", "atom",
                                  "bpmn", "csl" ),
            loadIcon("images/lang/xml.png")
        ),
        "go" to LangFileTypeInfo(
            "go", "Go", arrayOf("go"), loadIcon("images/lang/go.png")
        ),
        "basic" to LangFileTypeInfo(
            "basic", "BASIC", arrayOf("bas", "vb", "vbs", "cls"), loadIcon("images/lang/basic.png")
        ),
        "plain" to LangFileTypeInfo(
            "plain", strBundle.getString("txt_plain_text"), arrayOf("txt", "text", "csv", "ini", "cfg", "properties"),
            loadIcon("images/lang/plain_text.png")
        )
    )

// Pre-scale tree icons
val ICON_TREE_SIZE = sizesBundle( "tree_icon_size" )
val TREE_SCALED_ICON_MAP = mapOf(
        /* folder icons */
        "package" to loadIcon( "images/package.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "project" to loadIcon( "images/project.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        /* lang icons */
        "java" to EXTENSION_MAP["java"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "c" to EXTENSION_MAP["c"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "c++" to EXTENSION_MAP["c++"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "kotlin" to EXTENSION_MAP["kotlin"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "python" to EXTENSION_MAP["python"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "html" to EXTENSION_MAP["html"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "css" to EXTENSION_MAP["css"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "js" to EXTENSION_MAP["js"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "php" to EXTENSION_MAP["php"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "xml" to EXTENSION_MAP["xml"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "go" to EXTENSION_MAP["go"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "basic" to EXTENSION_MAP["basic"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "plain" to EXTENSION_MAP["plain"]?.icon?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        /* info node icons */
        "files" to loadIcon( "images/files.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "file_lines" to loadIcon( "images/file_lines.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "code" to loadIcon( "images/code.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "blank" to loadIcon( "images/blank.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "comments" to loadIcon( "images/comments.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE ),
        "delimiters" to loadIcon( "images/delimiter.png" )?.scaledIcon( ICON_TREE_SIZE, ICON_TREE_SIZE )
)
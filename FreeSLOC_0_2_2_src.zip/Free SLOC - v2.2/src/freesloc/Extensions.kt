package freesloc

import sun.reflect.generics.tree.Tree
import java.awt.Image
import java.text.DecimalFormat
import javax.swing.ImageIcon
import javax.swing.JTree
import javax.swing.tree.TreeNode

/** Expand all nodes */
tailrec fun JTree.expandAll()
{
    val rows = rowCount

    for ( i in 0 until rows )
        expandRow(i)

    if (  rowCount != rows )
        expandAll()
}

/** collapse all nodes */
tailrec fun JTree.collapseAll()
{
    val rows = rowCount

    for ( i in rows-1 downTo 0 )
        collapseRow(i)

    if ( rowCount != rows )
        collapseAll()
}

/** Apply action for every node in preorder */
fun JTree.visitAllPreorder( node: TreeNode, action: (TreeNode) -> Unit )
{
    action(node)

    for ( i in 0 until node.childCount )
        visitAllPreorder( node.getChildAt(i), action )
}

/** Apply action for every node in postorder */
fun JTree.visitAllPostorder( node: TreeNode, action: (TreeNode) -> Unit )
{
    for ( i in 0 until node.childCount )
        visitAllPostorder( node.getChildAt(i), action )

    action(node)
}

fun JTree.numberNodes() : Int
{
    var count = 0

    visitAllPreorder( model.root as TreeNode ) { count++ }

    return count
}

/** Scale ImageIcon returning an ImageIcon of [w]·[h] size */
fun ImageIcon.scaledIcon( w: Int, h: Int ): ImageIcon = ImageIcon( image.getScaledInstance( w, h, Image.SCALE_FAST ) )

/** Format double to given digits */
infix fun Double.format( digits: Int ) = DecimalFormat( "#.${"#".repeat(digits)}" ).format( this )!!

/**
 * Extension function for editor kit to append text with EOL
 *
fun HTMLEditorKit.appendln( doc : HTMLDocument, s: String )
{
try
{
insertHTML( doc, doc.length, s + System.lineSeparator(), 0, 0, null )
}
catch ( e: BadLocationException) { e.printStackTrace() }
catch ( e: IOException) { e.printStackTrace() }
}*/
